#include <stdlib.h>
#include <stdio.h>

int foo(int bar)
{
  char a[4];
	scanf("%s",a);
}

int main(int argc, char** argv)
{
	foo(argc);

	return 0;
}
