Grupo 305- 
Marta Oliveira 97613
Bruno Silva 97931
Miguel Ferreira 98345
Gonçalo Aguiar 98266
Bruno Acioli 101077 


O código realizado nesta iteração encontra-se no seguinte repositório: 

< https://github.com/detiuaveiro/as-Projeto> 

Para correr o código é necessário instalar o IDE Android Studio. 

Depois de instalar o IDE é necessário abrir o projeto no path ‘*\AS_Projeto\as-Projeto\IHC_Projeto_Oficial’ através da opção Open File no Android Studio. 

A seguir é necessário instalar um emulador de um smartphone Android para correr o código e para fazer isso é necessário selecionar a opção AVD Manager no Android Studio 
 

O emulador que escolhemos foi o Pixel 5 com a API 30.  

Por fim selecionar o emulador escolhido e carregar em ‘play’.  


O ficheiro de teste encontra-se no github no caminho “as-Projeto/IHC_Projeto_Oficial/app/src/androidTest/java/com/example/ihc_projeto_oficial/ LoginTest2.java” 