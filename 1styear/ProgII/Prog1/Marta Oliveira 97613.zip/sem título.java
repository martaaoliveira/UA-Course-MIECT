//[1,2,3,2,2,3] ==>6
public static int soma_de_dois(int[]lista {
	int soma=0;
	for (int i = 0; i < lista.length; i++)
	{
		if(lista[i]==2){
			soma+=lista[i];
		}
		return soma;
	}
	
}
